import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import { errorHandler } from "./core/middleware/errorHandler.js";
import customerRoutes from "./modules/customer/customer.routes.js";
import { toNodeHandler } from "better-auth/node";
import { auth } from "./lib/auth/auth.js";

const app = express();

app.use(helmet());
app.use(cors());
app.use(compression());
app.use(errorHandler);

// ✅ Better Auth MUST come before express.json()
app.all("/api/auth/*splat", toNodeHandler(auth));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

export default app;
