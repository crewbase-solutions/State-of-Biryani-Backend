import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { phoneNumber } from "better-auth/plugins";

import { prisma } from "../database/prisma.js";

export const auth = betterAuth({
  database: prismaAdapter(prisma, {
    provider: "postgresql",
  }),

  secret: process.env.BETTER_AUTH_SECRET!,

  baseURL: process.env.BETTER_AUTH_URL!,

  emailAndPassword: {
    enabled: false,
  },

  plugins: [
    phoneNumber({
      otpLength: 6,

      expiresIn: 300,

      async sendOTP({ phoneNumber, code }) {
        // Development
        console.log(`
====================================
PHONE : ${phoneNumber}
OTP   : ${code}
====================================
        `);

        // Later
        // await MSG91.send(phoneNumber, code);
      },

      signUpOnVerification: {
        getTempEmail(phoneNumber) {
          return `${phoneNumber}@stateofbiryani.app`;
        },

        getTempName(phoneNumber) {
          return phoneNumber;
        },
      },

      async callbackOnVerification({ user }) {
        console.log("Verified:", user.phoneNumber);

        // TODO
        // Create Customer Profile
      },
    }),
  ],
});