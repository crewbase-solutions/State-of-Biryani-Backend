import { z } from "zod";
import dotenv from "dotenv";

dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production"]).default("development"),

  PORT: z.coerce.number().default(5000),

  MONGO_URI: z.string().min(1, "MongoDB URI is required"),

  JWT_ACCESS_SECRET: z.string().min(10),

  JWT_REFRESH_SECRET: z.string().min(10),

  REDIS_URL: z.string().min(1, "Redis URL is required"),

  DATABASE_URL: z.string().min(1, "Database URL is required")
});

export const env = envSchema.parse(process.env);