import { Request, Response } from "express";
import { asyncHandler } from "../../core/middleware/asyncHandler.js";
import { ApiResponse } from "../../core/responses/ApiResponse.js";
import { customerService } from "./customer.service.js";

interface CustomerParams {
  id: string;
}

class CustomerController {
  create = asyncHandler(async (req: Request, res: Response) => {
    const customer = await customerService.createCustomer(req.body);
    ApiResponse.success(res, "Customer created successfully", customer, 201);
  });

  getAll = asyncHandler(async (_req: Request, res: Response) => {
    const customers = await customerService.getAllCustomers();
    ApiResponse.success(res, "Customers fetched successfully", customers);
  });

  getById = asyncHandler(async (req: Request<CustomerParams>, res: Response) => {
    const customer = await customerService.getCustomerById(req.params.id);
    ApiResponse.success(res, "Customer fetched successfully", customer);
  });

  update = asyncHandler(async (req: Request<CustomerParams>, res: Response) => {
    const customer = await customerService.updateCustomer(req.params.id, req.body);
    ApiResponse.success(res, "Customer updated successfully", customer);
  });

  delete = asyncHandler(async (req: Request<CustomerParams>, res: Response) => {
    await customerService.deleteCustomer(req.params.id);
    ApiResponse.success(res, "Customer deleted successfully");
  });
}

export const customerController = new CustomerController();
