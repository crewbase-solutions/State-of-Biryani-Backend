import { Document, Schema, Types, model } from "mongoose";

export interface ICustomerProfile extends Document {
  authUserId: string;
  profileImage?: string;
  favoriteItems: Types.ObjectId[];
  favoriteBranches: Types.ObjectId[];
  addresses: Types.ObjectId[];
  preferences: {
    spiceLevel?: string;
    vegPreference?: string;
  };
  role: "CUSTOMER";
  createdAt: Date;
  updatedAt: Date;
}

const customerProfileSchema = new Schema<ICustomerProfile>(
  {
    authUserId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },

    profileImage: {
      type: String,
    },

    favoriteItems: [
      { type: Schema.Types.ObjectId, ref: "MenuItem" }
    ],

    favoriteBranches: [
      { type: Schema.Types.ObjectId, ref: "Branch" }
    ],

    addresses: [
      { type: Schema.Types.ObjectId, ref: "Address" }
    ],

    preferences: {
      spiceLevel: { type: String },
      vegPreference: { type: String },
    },

    role: {
      type: String,
      enum: ["CUSTOMER"],
      default: "CUSTOMER",
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const CustomerProfile = model<ICustomerProfile>("CustomerProfile", customerProfileSchema);
