import { ICustomerProfile, CustomerProfile } from "./customer.model.js";
import { AppError } from "../../core/errors/AppError.js";

class CustomerService {
  async createCustomer(data: Partial<ICustomerProfile>) {
    const existing = await CustomerProfile.findOne({ authUserId: data.authUserId });
    if (existing) throw new AppError("Customer profile already exists", 409);
    return await CustomerProfile.create(data);
  }

  async getAllCustomers() {
    return await CustomerProfile.find()
      .populate("favoriteItems")
      .populate("favoriteBranches")
      .populate("addresses");
  }

  async getCustomerById(id: string) {
    const customer = await CustomerProfile.findById(id)
      .populate("favoriteItems")
      .populate("favoriteBranches")
      .populate("addresses");
    if (!customer) throw new AppError("Customer not found", 404);
    return customer;
  }

  async updateCustomer(id: string, data: Partial<ICustomerProfile>) {
    const customer = await CustomerProfile.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
    if (!customer) throw new AppError("Customer not found", 404);
    return customer;
  }

  async deleteCustomer(id: string) {
    const customer = await CustomerProfile.findByIdAndDelete(id);
    if (!customer) throw new AppError("Customer not found", 404);
  }
}

export const customerService = new CustomerService();
