import app from "./app.js";
import { env } from "./lib/env.js";
import { connectDB } from "./lib/database/mongodb.js";
import { connectRedis } from "./lib/cache/redis.js";
import { connectPostgres } from "./lib/database/prisma.js";

const startServer = async () => {
  try {
    await connectDB();
    await connectRedis();
    await connectPostgres();

    app.listen(env.PORT, () => {
      console.log(`🚀 Server running at http://localhost:${env.PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server", error);
    process.exit(1);
  }
};

startServer();
